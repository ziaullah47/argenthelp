﻿using System;
using System.IO;
using System.Text;
using System.Text.RegularExpressions;

class Program
{
    static void Main()
    {
        // Read the prompt from Input file
        string filePath = "input.txt";

        if (!File.Exists(filePath))
        {
            throw new FileNotFoundException($"The file '{filePath}' was not found.");
        }

        string prompt = File.ReadAllText(filePath);
        // Convert prompt to HTML
        string html = ConvertPromptToHtml(prompt);

        // Write the output to Output file
        SaveHtmlToFile(html, "output.html");

    }

    static string ConvertPromptToHtml(string prompt)
    {
        StringBuilder sb = new StringBuilder();

        // Include CSS in the <head> section
        sb.AppendLine("<html>");
        sb.AppendLine("<head>");
        sb.AppendLine("<style>");
        sb.AppendLine("body { font-family: 'Open Sans', sans-serif; }");
        sb.AppendLine(".post-card-content { margin: 20px; }");
        sb.AppendLine(".post-title { color: rgb(1, 92, 139); font-size: 28px; font-weight: 400; margin-top: 25px; line-height: 33.6px; }");
        sb.AppendLine(".subtitle { color: rgb(190, 72, 0); font-size: 20px; font-weight: 500; margin-top: 32px; }");
        sb.AppendLine(".content { font-size: 13px; line-height: 20px; margin-top: 12px; }");
        sb.AppendLine(".thumbnail { margin-top: 32px; border: solid 1px gray; }");
        sb.AppendLine("</style>");
        sb.AppendLine("</head>");
        sb.AppendLine("<body>");
        sb.AppendLine("<div class=\"post-card-content\">");

        // Modified Regex pattern to match tags and multi-line content
        string pattern = @"\[(.*?)\]\s*\[(.*?)\]";
        MatchCollection matches = Regex.Matches(prompt, pattern, RegexOptions.Singleline);

        Console.Write(prompt);
        foreach (Match match in matches)
        {
            string tag = match.Groups[1].Value.ToUpper();
            string content = match.Groups[2].Value.Trim();


            // Replace new lines with <br> for proper HTML formatting
            content = content.Replace("\n", "<br>");
            // Bold all words enclosed in ""
            content = Regex.Replace(content, @"""([^""]*)""", @"<b>""$1""</b>");

            switch (tag)
            {
                case "TITLE":
                    sb.AppendLine($"<h2 class=\"post-title\">{content}</h2>");
                    break;

                case "VERSION":
                    sb.AppendLine("<p class=\"subtitle\">Version</p>");
                    sb.AppendLine($"<p class=\"content\">{content}</p>");
                    break;

                case "DATE":
                    sb.AppendLine("<p class=\"subtitle\">Date</p>");
                    sb.AppendLine($"<p class=\"content\">{content}</p>");
                    break;

                case "SUMMARY":
                    sb.AppendLine("<p class=\"subtitle\">Summary</p>");
                    sb.AppendLine($"<p class=\"content\">{content}</p>");
                    break;

                case "TECHNICAL BACKGROUND":
                    sb.AppendLine("<p class=\"subtitle\">Technical Background</p>");
                    sb.AppendLine($"<p class=\"content\">{content}</p>");
                    break;

                case "IMAGE":
                    sb.AppendLine($"<img src=\"{content}\" class=\"thumbnail\"><br>");
                    break;

                case "TEXT":
                    sb.AppendLine($"<p class=\"content\">{content}</p>");
                    break;

                case "RESOLUTION":
                    sb.AppendLine("<p class=\"subtitle\">Resolution</p>");
                    sb.AppendLine($"<p class=\"content\">{content}</p>");
                    break;

                default:
                    sb.AppendLine($"<p class=\"subtitle\">{tag}</p>");
                    sb.AppendLine($"<p class=\"content\">{content}</p>");
                    break;
            }
        }

        sb.AppendLine("</div>");
        sb.AppendLine("</body>");
        sb.AppendLine("</html>");

        return sb.ToString();
    }

    static void SaveHtmlToFile(string html, string filePath)
    {
        using (StreamWriter writer = new StreamWriter(filePath))
        {
            writer.Write(html);
        }
    }
}
